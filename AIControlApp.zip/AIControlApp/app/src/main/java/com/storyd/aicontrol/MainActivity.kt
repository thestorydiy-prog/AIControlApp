package com.storyd.aicontrol

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var whitelistText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        whitelistText = findViewById(R.id.whitelistText)

        findViewById<Button>(R.id.btnOpenAccessibilitySettings).setOnClickListener {
            // พาไปหน้า Settings ของระบบ - ผู้ใช้ต้องกดเปิดเองเท่านั้น
            // (Android ไม่อนุญาตให้แอพเปิดสิทธิ์นี้ให้ตัวเองอัตโนมัติ)
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnClearWhitelist).setOnClickListener {
            val prefs = getSharedPreferences("ai_control_prefs", Context.MODE_PRIVATE)
            prefs.edit().remove("whitelisted_packages").apply()
            refreshStatus()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val enabled = isAccessibilityServiceEnabled()
        statusText.text = if (enabled)
            "สถานะ: เปิดใช้งานอยู่ ✅"
        else
            "สถานะ: ยังไม่ได้เปิดสิทธิ์ Accessibility ❌\nกดปุ่มด้านล่างเพื่อไปเปิด"

        val prefs = getSharedPreferences("ai_control_prefs", Context.MODE_PRIVATE)
        val whitelist = prefs.getStringSet("whitelisted_packages", emptySet()) ?: emptySet()
        whitelistText.text = if (whitelist.isEmpty())
            "ยังไม่มีแอพที่อนุญาตไว้"
        else
            "แอพที่อนุญาตแล้ว:\n" + whitelist.joinToString("\n") { "• $it" }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val service = "$packageName/${ControlAccessibilityService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(service)
    }
}
