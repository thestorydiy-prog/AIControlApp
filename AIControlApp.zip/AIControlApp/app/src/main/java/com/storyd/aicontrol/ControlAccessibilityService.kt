package com.storyd.aicontrol

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.os.Build
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.TextView

/**
 * หัวใจของระบบควบคุม
 *
 * กฎการทำงาน (เรียงตามลำดับความสำคัญ ห้ามสลับ):
 *  1. เจอ "ฟิลด์รหัสผ่าน / PIN / OTP" บนจอ -> หยุดทุกการกระทำทันที ไม่สนใจ whitelist
 *  2. แอพที่ยังไม่เคยอนุญาต -> โชว์ popup ถามก่อนเสมอ ไม่ทำอะไรจนกว่าจะตอบ
 *  3. แอพที่อนุญาตแล้ว (whitelist) -> อ่านหน้าจอ/ส่งคำสั่งได้ตามปกติ (ยกเว้นกฎข้อ 1 ที่ชนะเสมอ)
 */
class ControlAccessibilityService : AccessibilityService() {

    private lateinit var prefs: SharedPreferences
    private var overlayView: View? = null
    private var windowManager: WindowManager? = null
    private var lastPromptedPackage: String? = null

    companion object {
        private const val TAG = "AIControlService"
        private const val PREFS_NAME = "ai_control_prefs"
        private const val KEY_WHITELIST = "whitelisted_packages"

        // แอพของระบบที่ไม่ต้องถามอนุญาต (launcher, ตัว service เอง ฯลฯ)
        private val ALWAYS_IGNORE = setOf(
            "com.android.systemui",
            "com.storyd.aicontrol"
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        Log.i(TAG, "Service connected - whitelist = ${getWhitelist()}")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (ALWAYS_IGNORE.contains(pkg)) return

        val root = rootInActiveWindow ?: return

        // ===== กฎข้อ 1: ตรวจฟิลด์รหัสผ่านก่อนเสมอ ไม่ว่าแอพจะอยู่ใน whitelist หรือไม่ =====
        if (containsPasswordField(root)) {
            Log.i(TAG, "Password field detected in $pkg - BLOCKING all automation here")
            // ไม่ทำอะไรต่อทั้งสิ้น: ไม่กรอก ไม่กดปุ่ม ไม่อ่านค่าในช่องนั้น
            // คนต้องกรอกเองเท่านั้น
            return
        }

        // ===== กฎข้อ 2: แอพใหม่ที่ยังไม่อนุญาต ต้องถามก่อน =====
        if (!getWhitelist().contains(pkg)) {
            promptUserForPermission(pkg)
            return
        }

        // ===== กฎข้อ 3: แอพอยู่ใน whitelist แล้ว - ทำงานตามคำสั่งปกติได้ =====
        // ตรงนี้คือจุดที่ต่อยอด logic อ่าน/สั่งงานแอพนั้นๆ เพิ่มเติมได้
        // เช่น หา node ด้วยข้อความแล้วกด performAction(ACTION_CLICK)
    }

    /**
     * เช็คทุก node บนจอว่ามีช่องที่เป็นรหัสผ่านไหม
     * ใช้ isPassword flag ของ Android ซึ่งทุกแอพที่ทำถูกหลัก (ธนาคาร, เทรด, ล็อกอินทั่วไป)
     * จะ set flag นี้ไว้ที่ EditText รหัสผ่านเสมอ
     */
    private fun containsPasswordField(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        if (node.isPassword) return true

        // เผื่อแอพบางตัวไม่ set isPassword แต่บอกผ่าน hint/label แทน
        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val suspiciousWords = listOf("password", "รหัสผ่าน", "pin", "otp", "รหัส pin", "เลข pin")
        if (suspiciousWords.any { text.contains(it) || desc.contains(it) }) {
            return true
        }

        for (i in 0 until node.childCount) {
            if (containsPasswordField(node.getChild(i))) return true
        }
        return false
    }

    /**
     * โชว์ popup ลอยทับหน้าจอถามว่า "อนุญาตแอพนี้ไหม"
     * ไม่ทำอะไรกับแอพนั้นจนกว่าคนจะตอบ
     */
    private fun promptUserForPermission(pkg: String) {
        if (overlayView != null) return // popup ค้างอยู่แล้ว รอคนตอบก่อน
        if (lastPromptedPackage == pkg) return // กันถามซ้ำรัวๆ จาก event เดียวกัน
        lastPromptedPackage = pkg

        val appName = try {
            val pm = packageManager
            val info = pm.getApplicationInfo(pkg, 0)
            pm.getApplicationLabel(info).toString()
        } catch (e: Exception) {
            pkg
        }

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_permission_prompt, null)
        val titleView = view.findViewById<TextView>(R.id.promptTitle)
        val btnAllow = view.findViewById<Button>(R.id.btnAllow)
        val btnDeny = view.findViewById<Button>(R.id.btnDeny)

        titleView.text = "อนุญาตให้ AI สั่งงานแอพ \"$appName\" ไหม?"

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP

        btnAllow.setOnClickListener {
            addToWhitelist(pkg)
            removeOverlay()
        }
        btnDeny.setOnClickListener {
            removeOverlay()
        }

        windowManager?.addView(view, params)
        overlayView = view
    }

    private fun removeOverlay() {
        overlayView?.let {
            windowManager?.removeView(it)
            overlayView = null
            lastPromptedPackage = null
        }
    }

    private fun getWhitelist(): Set<String> {
        return prefs.getStringSet(KEY_WHITELIST, emptySet()) ?: emptySet()
    }

    private fun addToWhitelist(pkg: String) {
        val current = getWhitelist().toMutableSet()
        current.add(pkg)
        prefs.edit().putStringSet(KEY_WHITELIST, current).apply()
        Log.i(TAG, "Added $pkg to whitelist")
    }

    override fun onInterrupt() {
        Log.w(TAG, "Service interrupted")
    }
}
